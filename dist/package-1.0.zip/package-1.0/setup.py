from distutils.core import setup

setup(name='package',
      version='1.0',
      py_modules=['launcher', 'gmail', 'internetbook', 'scriptUI']
      )
